// Abertura do arquivo OK
// Conversão das regras lidas para os tipos OK
// Verificar como foram lidas OK
// Criar array de status OK
// Registrar a certeza de cada conclusão nas regras EM ANDAMENTO URGENTE TODO
// Utilizar recursão para fazer o backward chaining EM ANDAMENTO
// Testar função findNextRule TODO

package motordeinferencia;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.Stack;

public class Engine {

    /*USED BY INFERENCE MACHINES*/
    public ArrayList<Rule> rules = new ArrayList<Rule>();//all rules
    public ArrayList<Variable> variables = new ArrayList<Variable>();//fact base
    public Variable goalVariable;
    public int[] ruleVisited;//Durante a inferência o motor irá procurar relações sequencialmente,
                             //essa variável aqui indica que ele já visitou uma regra (já analisou completamente)
    
    
    public Stack<Variable> objectives = new Stack<Variable>(); //Stack contendo as variáveis que queremos saber o valor
    public ArrayList<Variable> known = new ArrayList<Variable>();//Conjunto de variáveis conhecidas
    
    
    //USED BY PROGRAMMING
    Utils utils;
    String saux;
    Variable newVariable;
    BufferedReader arquivoAberto;
    
    /*INÍCIO FUNÇÕES NÃO RELACIONADAS COM A MÁQUINA DE INFERÊNCIA*/
    public void askForRules(){
        System.out.println("[!] Digite o nome do arquivo:");
        saux = utils.read.nextLine();
        File arquivo = new File(saux);
        try{
            arquivoAberto = new BufferedReader(new FileReader(arquivo));
            System.out.println("[!] Arquivo lido com sucesso!");
            convertToRules();
        }catch(FileNotFoundException e){
            System.out.println("[!] ERRO: Arquivo não encontrado!");
        }
    }
    
    public void defineVariables(){
        String title;
        int iopt;
        String option;
        System.out.println("[!] Você deseja registrar uma variável? [S/N]");
        option = utils.read.nextLine();
        option = option.toLowerCase();
        while (option.equals("s")){

            System.out.println("[+] Digite o nome da variável:");
            title = utils.read.nextLine();

            newVariable = new Variable(title,"nãopreenchido", false);

            variables.add(newVariable);

            System.out.println("[!] Foram registradas um total de "+ variables.size() + " variáveis");

            System.out.println("[!] Deseja registrar outra variável conhecida? [S/N]");
            option = utils.read.nextLine();
        }
    }

    public void defineGoal(){
        String name;
        System.out.println("[+] Digite o nome da variável objetivo:");
        name = utils.read.nextLine();

        goalVariable = new Variable(name,"nãopreenchido",true);
        //establishFact(goalVariable);
    }

    

    //NÃO FINALIZADO
    public void convertToRules(){
      boolean bAux;
      String sConclusionAux;
      String[] splitConclusion;
      String line = null;
      String [] splitLine;
      Rule newRule = null;
      ArrayList<Variable> allPremises = new ArrayList<Variable>();
      Variable newVariable = null;
      
      int ruleNumber = 1;

      while((line = readFromFile()) != null){
        splitLine = line.split("\\s");
        
        //System.out.println("TESTE: "+ Arrays.deepToString(splitLine));//teste
        
        allPremises = splitVariable(splitLine);

        sConclusionAux = splitLine[splitLine.length - 6];
        splitConclusion = sConclusionAux.split("=");

        if(splitConclusion[0].equals(goalVariable))
        {
            bAux = true;
        }
        else{
            bAux = false;
        }
        newVariable = new Variable(splitConclusion[0],splitConclusion[1],bAux);
        
       

        newRule = new Rule(allPremises, newVariable,ruleNumber);

        rules.add(newRule);
        
        ruleNumber++;
      }
      
      
      //Criando o array de controle de regras visitadas com tamanho igual ao número de regras
      ruleVisited = new int[rules.size()];
      
      //Setando cada uma das regras como 0 (não visitada)
      for(int i = 0 ;i<rules.size();i++){
          ruleVisited[i] = 0;
      }
    }
    
    
    //Essa função está relacionada com a convertToRules(), seu papel é quebrar as strings, separando e registrando as variáveis
    public ArrayList<Variable> splitVariable(String[] splitLine){
      ArrayList<Variable> allPremises = new ArrayList<Variable>();
      String sVariableAux;
      String[] splitVariable;
      Variable newVariable = null;
      boolean bAux;
      int i=1;

      while(i<= splitLine.length - 9){
        sVariableAux = splitLine[i];
        splitVariable = sVariableAux.split("=");
        
          //System.out.println("PASSOU1");//teste
        
        newVariable = new Variable(splitVariable[0],splitVariable[1],false);
         //System.out.println("PASSOU2");//teste

        allPremises.add(newVariable);
         //System.out.println("PASSOU3");//teste

        i++;
    
      }
      
      //System.out.println("PASSOU4");

      return allPremises;
    }

    //Função que busca variáveis
    public Variable findVariable(String name, ArrayList<Variable> variables){
        Variable st;
       for(int i = 0; variables.size()>i;i++){
           st = variables.get(i);
           if(st.getName().equals(name)){
               return st;
           }
       }
       return null;
    }
    
    //Lê somente uma linha do arquivo com tratamento de exceção
    public String readFromFile(){
      String line = null;

      try{
        line = arquivoAberto.readLine();
      }catch(IOException e){
        System.out.println("[!] Erro: Falha ao ler o arquivo!");
      }

      return line;
    }

    public void result(boolean res){
        System.out.println("[!] A resposta é: " + res);
    }
    
    
    //Função pra verificar o funcionamento da convertToRules()
    public void testRules(){
        ArrayList<Variable> teste;
        Variable testeConcl;
        int i=0;
        
        
        while(i<rules.size()){
            teste = rules.get(i).getPremises();
            testeConcl = rules.get(i).getConclusion();
            System.out.println("Regra "+i+": ");
            for(int j = 0; j<teste.size();j++){
                System.out.println("        Premissa "+j+": Variável> "+ teste.get(j).getName()+" Valor> "+teste.get(j).getValue() );
            }
            System.out.println("        Conclusão: Variável> "+ testeConcl.getName()+" Valor> "+testeConcl.getValue());
            i++;
        }
    }
    
    /*FIM DAS FUNÇÕES NÃO RELACIONADAS COM O MOTOR DE INFERÊNCIA*/
    
    /*MOTOR DE INFERÊNCIA*/
    public void run(){
        Stack<Variable> iObjectives = new Stack<Variable>();
        iObjectives.push(goalVariable);
      
        inference(iObjectives);
        
        //Após isso devemos buscar a classe que queremos saber no arraylist de variáveis conhecidas (known) e dar o resultado TODO
    }
    
    //A ideia aqui é usar a recursão
    public void inference(Stack<Variable> iObjectives){
        if(!iObjectives.empty()){
            Variable actualGoal = iObjectives.pop();
            boolean solved = false;

            while(!solved){//Esse loop só vai acabar quando eu tiver um resultado
                Rule nextRule = findNextRule(actualGoal.getName(),true);
                if(nextRule != null){//Ainda existem regras que podem ajudar a resolver
                    ArrayList<Variable> nextRulePremises = nextRule.getPremises();
                    verifyPremises(nextRulePremises,iObjectives);//Já tenho todas as respostas que preciso para responder a minha conclusão
                    if(matchRule(nextRule)){//Se a regra foi satisfeita, a conclusão da regra vai estar no conjunto de variáveis conhecidas (known)
                        solved = true;
                        break;
                    }
                }else{//temos que perguntar ao usuário
                    String value = generateGoodQuestions(actualGoal);
                    //Perguntar qual a certeza sobre isso TODO
                    //Esquema do fator de certeza: Multiplico as certezas das premissas umas pelas outras, multiplico pela conclusão e divido por 10^(1+quantidade de premissas)
                    //usar a função verifyPremises TODO
                }
            }
        }
    }
    
    //Essa função determina como serão as perguntas feitas pelo motor de inferência
    public String generateGoodQuestions(Variable actualGoal){
        if(actualGoal.getName().equals("age")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor numérico esperado");
            int value = utils.readInt();
            
            if(value < 12){
                return "'(-inf-11.5]'";
            }else if(value>44){
                return "'(44.5-inf)'";
            }else{
                return "'(11.5-44.5]'";
            }    
        }else if(actualGoal.getName().equals("bp")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor numérico esperado");
            int value = utils.readInt();
            
            if(value <= 85){
                return "'(-inf-85]'";
            }else{
                return "'(85-inf)'";
            }
        }else if(actualGoal.getName().equals("sg")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 1.0175){
                return "'(-inf-1.0175]'";
            }else if(value > 1.0225){
                return "'(1.0225-inf)'";
            }else{
                return "'(1.0175-1.0225]'";
            }
        }else if(actualGoal.getName().equals("al")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 0.5){
                return "'(-inf-0.5]'";
            }else{
                return "'(0.5-inf)'";
            }
        }else if(actualGoal.getName().equals("su")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 0.5){
                return "'(-inf-0.5]'";
            }else{
                return "'(0.5-inf)'";
            }
        }else if(actualGoal.getName().equals("rbc")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: normal ou abnormal)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("pc")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: normal ou abnormal)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("pcc")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: present ou notpresent)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("ba")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: present ou notpresent)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("bgr")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 140.5){
                return "'(-inf-140.5]'";
            }else{
                return "'(140.5-inf)'";
            }
        }else if(actualGoal.getName().equals("bu")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 50.5){
                return "'(-inf-50.5]'";
            }else{
                return "'(50.5-inf)'";
            }
        }else if(actualGoal.getName().equals("sc")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 1.25){
                return "'(-inf-1.25]'";
            }else{
                return "'(1.25-inf)'";
            }
        }else if(actualGoal.getName().equals("sod")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 134.5){
                return "'(-inf-134.5]'";
            }else if(value > 134.5 && value <= 138.5){
                return "'(134.5-138.5]'";
            }else if(value > 138.5 && value <= 143.5){
                return "'(138.5-143.5]'";
            }else{
                return "'(143.5-inf)'";
            }
        }else if(actualGoal.getName().equals("pot")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 4.45){
                return "'(-inf-4.45]'";
            }else if(value > 5.05){
                return "'(5.05-inf)'";
            }else{
                return "'(4.45-5.05]'";
            }
        }else if(actualGoal.getName().equals("hemo")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 12.95){
                return "'(-inf-12.95]'";
            }else if(value > 12.95 && value <= 14.95){
                return "'(12.95-14.95]'";
            }else if(value > 14.95 && value <= 15.05){
                return "'(14.95-15.05]'";
            }else{
                return "'(15.05-inf)'";
            }
        }else if(actualGoal.getName().equals("pcv")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            if(value <= 39.5){
                return "'(-inf-39.5]'";
            }else if(value > 39.5 && value <= 47.5){
                return "'(39.5-47.5]'";
            }else if(value > 47.5 && value <= 51.5){
                return "'(47.5-51.5]'";
            }else if(value > 51.5 && value <= 52.5){
                return "'(51.5-52.5]'";
            }else{
                return "'(52.5-inf)'";
            }
        }else if(actualGoal.getName().equals("wbcc")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor numérico esperado");
            int value = utils.readInt();
            
            if(value <= 9750){
                return "'(-inf-9750]'";
            }else{
                return "'(9750-inf)'";
            }
        }else if(actualGoal.getName().equals("rbcc")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? *Valor flutuante esperado (Formato: XX.X)");
            float value = utils.readFloat();
            
            return Float.toString(value);
        }else if(actualGoal.getName().equals("htn")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: yes ou no)");
            String value = utils.read.nextLine(); 
            return value;
        }
        else if(actualGoal.getName().equals("dm")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: yes ou no)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("cad")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: yes ou no)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("appet")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: good ou poor)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("pe")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: yes ou no)");
            String value = utils.read.nextLine(); 
            return value;
        }else if(actualGoal.getName().equals("ane")){
            System.out.println("[Motor de Inferência] Qual o valor da variável " + actualGoal.getName()+"? (Opções: yes ou no)");
            String value = utils.read.nextLine(); 
            return value;
        }
        
        return null;
    }
    
    //Verifica se todas as premissas já foram atendidas, caso não adiciona na pilha de objetivos
    public void verifyPremises(ArrayList<Variable> premises, Stack<Variable> iObjectives){
        Variable vaux;//variável de auxilio, irá receber variáveis das premissas para serem comparadas
        String saux;
        Variable foundVariable =  null;//situação no conjunto de variáveis que já conhecemos
        boolean allRight = true;//Se tudo estiver certo é porque todas as premissas já foram atendidas
        Stack<Variable> subGoals = new Stack<Variable>();
        
        for(int i = 0; i < premises.size(); i++){
            vaux = premises.get(i);
            foundVariable = findVariable(vaux.getName(),known);
            if(foundVariable == null){
                subGoals.push(vaux);
                inference(subGoals);//no final daqui, as premissas terão resultado
            }
        }
    }
    
    //Diz se a regra é satisfeita ou não visto que já tenho as informações sobre elas
    public boolean matchRule(Rule rule){
        Variable vaux = null;
        Variable foundVariable;
        for(int i = 0; i < rule.getPremises().size(); i++){
            vaux = rule.getPremises().get(i);
            foundVariable = findVariable(vaux.getName(),known);
            if(foundVariable != null){
                if(!foundVariable.getValue().equals(vaux.getValue())){
                    return false;
                }
            }
        }
        known.add(rule.getConclusion());
        return true;
    }
    
    //procura a próxima regra com a conclusão que tem o nome da variável do parametro
    //e retorna essa regra. seta como visitado no array de regras visitadas caso a variavel esteja true
    public Rule findNextRule(String nameObjective, boolean setAsVisited){
        Variable testeConcl = null;
        for(int i = 0;i<rules.size();i++){
            testeConcl= rules.get(i).getConclusion();
            if(testeConcl.getName().equals(nameObjective)){
                if(setAsVisited)ruleVisited[i]=1;
                return rules.get(i);
            }
        }
        return null;
    }
    
    
    /*FIM DO MOTOR DE INFERÊNCIA*/
}
