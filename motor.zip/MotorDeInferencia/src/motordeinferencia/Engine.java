// Abertura do arquivo OK
// Conversão das regras lidas para os tipos OK
// Verificar como foram lidas OK
// Criar array de status OK
// Utilizar recursão para fazer o backward chaining EM ANDAMENTO

package motordeinferencia;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Stack;

public class Engine {

    /*USED BY INFERENCE MACHINES*/
    public ArrayList<Rule> rules = new ArrayList<Rule>();//all rules
    public ArrayList<Variable> variables = new ArrayList<Variable>();//fact base
    public Variable goalVariable;
    public int[] ruleVisited;//Durante a inferência o motor irá procurar relações sequencialmente,
                             //essa variável aqui indica que ele já visitou uma regra (já analisou completamente)
    
    
    public Stack<Variable> objectives = new Stack<Variable>(); //Stack contendo as variáveis que queremos saber o valor
    public Stack<Variable> known = new Stack<Variable>();//Stack contendo as variáveis que já sabemos
    
    
    //USED BY PROGRAMMING
    Utils utils;
    String saux;
    Variable newVariable;
    BufferedReader arquivoAberto;
    
    /*INÍCIO FUNÇÕES NÃO RELACIONADAS COM A MÁQUINA DE INFERÊNCIA*/
    public void askForRules(){
        System.out.println("[!] Digite o nome do arquivo:");
        saux = utils.read.nextLine();
        File arquivo = new File(saux);
        try{
            arquivoAberto = new BufferedReader(new FileReader(arquivo));
            System.out.println("[!] Arquivo lido com sucesso!");
            convertToRules();
        }catch(FileNotFoundException e){
            System.out.println("[!] ERRO: Arquivo não encontrado!");
        }
    }
    
    public void defineVariables(){
        String title;
        int iopt;
        String option;
        System.out.println("[!] Você deseja registrar uma variável? [S/N]");
        option = utils.read.nextLine();
        option = option.toLowerCase();
        while (option.equals("s")){

            System.out.println("[+] Digite o nome da variável:");
            title = utils.read.nextLine();

            newVariable = new Variable(title,"nãopreenchido", false);

            variables.add(newVariable);

            System.out.println("[!] Foram registradas um total de "+ variables.size() + " variáveis");

            System.out.println("[!] Deseja registrar outra variável conhecida? [S/N]");
            option = utils.read.nextLine();
        }
    }

    /*
    public void defineKnownVariables(){
        String title;
        int iopt;
        String option;
        System.out.println("[!] Deseja registrar uma variável conhecida? [S/N]");
        option = utils.read.nextLine();
        option = option.toLowerCase();
        while (option.equals("s")){

            System.out.println("[+] Digite o nome da variável:");
            title = utils.read.nextLine();
            System.out.println("[+] Digite 1 se o valor for VERDADEIRO (SIM) e 2 se o valor for FALSO (NÃO):");
            iopt = utils.read.nextInt();
            saux = utils.read.nextLine();

            if(iopt == 1) {
                newVariable = new Variable(title, true, false);
            }
            else{
                newVariable = new Variable(title, false, false);
            }

            knownVariables.add(newVariable);

            System.out.println("[!] Foram registradas um total de "+ knownVariables.size() + " variáveis");

            System.out.println("[!] Deseja registrar outra variável conhecida? [S/N]");
            option = utils.read.nextLine();
        }
    }
    */

    public void defineGoal(){
        String name;
        System.out.println("[+] Digite o nome da variável objetivo:");
        name = utils.read.nextLine();

        goalVariable = new Variable(name,"nãopreenchido",true);
        //establishFact(goalVariable);
    }

    

    //NÃO FINALIZADO
    public void convertToRules(){
      boolean bAux;
      String sConclusionAux;
      String[] splitConclusion;
      String line = null;
      String [] splitLine;
      Rule newRule = null;
      ArrayList<Variable> allPremises = new ArrayList<Variable>();
      Variable newVariable = null;
      
      int ruleNumber = 1;

      while((line = readFromFile()) != null){
        splitLine = line.split("\\s");
        
        //System.out.println("TESTE: "+ Arrays.deepToString(splitLine));//teste
        
        allPremises = splitVariable(splitLine);

        sConclusionAux = splitLine[splitLine.length - 6];
        splitConclusion = sConclusionAux.split("=");

        if(splitConclusion[0].equals(goalVariable))
        {
            bAux = true;
        }
        else{
            bAux = false;
        }
        newVariable = new Variable(splitConclusion[0],splitConclusion[1],bAux);
        
       

        newRule = new Rule(allPremises, newVariable,ruleNumber);

        rules.add(newRule);
        
        ruleNumber++;
      }
      
      
      //Criando o array de controle de regras visitadas com tamanho igual ao número de regras
      ruleVisited = new int[rules.size()];
      
      //Setando cada uma das regras como 0 (não visitada)
      for(int i = 0 ;i<rules.size();i++){
          ruleVisited[i] = 0;
      }
    }
    
    
    //Essa função está relacionada com a convertToRules(), seu papel é quebrar as strings, separando e registrando as variáveis
    public ArrayList<Variable> splitVariable(String[] splitLine){
      ArrayList<Variable> allPremises = new ArrayList<Variable>();
      String sVariableAux;
      String[] splitVariable;
      Variable newVariable = null;
      boolean bAux;
      int i=1;

      while(i<= splitLine.length - 9){
        sVariableAux = splitLine[i];
        splitVariable = sVariableAux.split("=");
        
          //System.out.println("PASSOU1");//teste
        
        newVariable = new Variable(splitVariable[0],splitVariable[1],false);
         //System.out.println("PASSOU2");//teste

        allPremises.add(newVariable);
         //System.out.println("PASSOU3");//teste

        i++;
    
      }
      
      //System.out.println("PASSOU4");

      return allPremises;
    }

    //Função que busca variáveis
    public Variable findVariable(String name, ArrayList<Variable> variables){
        Variable st;
       for(int i = 0; variables.size()>i;i++){
           st = variables.get(i);
           if(st.getName().equals(name)){
               return st;
           }
       }
       return null;
    }
    
    //Lê somente uma linha do arquivo com tratamento de exceção
    public String readFromFile(){
      String line = null;

      try{
        line = arquivoAberto.readLine();
      }catch(IOException e){
        System.out.println("[!] Erro: Falha ao ler o arquivo!");
      }

      return line;
    }

    public void result(boolean res){
        System.out.println("[!] A resposta é: " + res);
    }
    
    
    //Função pra verificar o funcionamento da convertToRules()
    public void testRules(){
        ArrayList<Variable> teste;
        Variable testeConcl;
        int i=0;
        
        
        while(i<rules.size()){
            teste = rules.get(i).getPremises();
            testeConcl = rules.get(i).getConclusion();
            System.out.println("Regra "+i+": ");
            for(int j = 0; j<teste.size();j++){
                System.out.println("        Premissa "+j+": Variável> "+ teste.get(j).getName()+" Valor> "+teste.get(j).getValue() );
            }
            System.out.println("        Conclusão: Variável> "+ testeConcl.getName()+" Valor> "+testeConcl.getValue());
            i++;
        }
    }
    
    /*FIM DAS FUNÇÕES NÃO RELACIONADAS COM O MOTOR DE INFERÊNCIA*/
    
    /*MOTOR DE INFERÊNCIA*/
    public void run(){
        Stack<Variable> iObjectives = new Stack<Variable>();
        ArrayList<Variable> iKnown = new ArrayList<Variable>();
        iObjectives.push(goalVariable);
      
        inference(iObjectives,iKnown);
        
    }
    
    //A ideia aqui é usar a recursão
    public void inference(Stack<Variable> iObjectives, ArrayList<Variable> iKnown){
        Variable actualGoal = iObjectives.pop();
        
    }
    
    //procura a próxima regra com a conclusão que tem o nome da variável do parametro
    //e retorna essa regra. seta como visitado no array de regras visitadas caso a variavel esteja true
    public Rule findNextRule(String nameObjective, boolean setAsVisited){
        Variable testeConcl = null;
        for(int i = 0;i<rules.size();i++){
            testeConcl= rules.get(i).getConclusion();
            if(testeConcl.getName().equals(nameObjective)){
                if(setAsVisited)ruleVisited[i]=1;
                return rules.get(i);
            }
        }
        return null;
    }
    
    
    /*FIM DO MOTOR DE INFERÊNCIA*/
}
