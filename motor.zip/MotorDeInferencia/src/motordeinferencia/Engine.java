//Até o momento já foi tudo convertido para objetos (rules)
//Agora é só aplicar o algoritmo

// É preciso colocar no inicio do arraylist
// Algoritmo parece não fazer muito sentido, analisar bem.

package motordeinferencia;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Iterator;

public class Engine {

    /*USED BY INFERENCE MACHINES*/
    ArrayList<Rule> rules = new ArrayList<Rule>();//all rules
    ArrayList<Variable> variables = new ArrayList<Variable>();//fact base
    Variable goalVariable;
    
    
    //USED BY PROGRAMMING
    Utils utils;
    String saux;
    Variable newVariable;
    BufferedReader readArch;//ARQUIVO LIDO
    
    public void run(){
        
    }
    
    /*
    public void runForwardsChaining(){
        askForRules();
        defineVariables();
        convertToRules();
        defineGoal();
        defineKnownVariables();
    }
    */

    public void askForRules(){
        System.out.println("[+] Digite o nome do arquivo:");
        saux = utils.read.nextLine();
        FileReader f = null;
        try{
          f = new FileReader(saux);
        }catch(FileNotFoundException e){
          System.out.println("[!] Erro: Arquivo não encontrado!");
        }
        readArch = new BufferedReader(f);
        convertToRules();
    }
    
    public void defineVariables(){
        String title;
        int iopt;
        String option;
        System.out.println("[!] Você deseja registrar uma variável? [S/N]");
        option = utils.read.nextLine();
        option = option.toLowerCase();
        while (option.equals("s")){

            System.out.println("[+] Digite o nome da variável:");
            title = utils.read.nextLine();

            newVariable = new Variable(title,"nãopreenchido", false);

            variables.add(newVariable);

            System.out.println("[!] Foram registradas um total de "+ variables.size() + " variáveis");

            System.out.println("[!] Deseja registrar outra variável conhecida? [S/N]");
            option = utils.read.nextLine();
        }
    }

    /*
    public void defineKnownVariables(){
        String title;
        int iopt;
        String option;
        System.out.println("[!] Deseja registrar uma variável conhecida? [S/N]");
        option = utils.read.nextLine();
        option = option.toLowerCase();
        while (option.equals("s")){

            System.out.println("[+] Digite o nome da variável:");
            title = utils.read.nextLine();
            System.out.println("[+] Digite 1 se o valor for VERDADEIRO (SIM) e 2 se o valor for FALSO (NÃO):");
            iopt = utils.read.nextInt();
            saux = utils.read.nextLine();

            if(iopt == 1) {
                newVariable = new Variable(title, true, false);
            }
            else{
                newVariable = new Variable(title, false, false);
            }

            knownVariables.add(newVariable);

            System.out.println("[!] Foram registradas um total de "+ knownVariables.size() + " variáveis");

            System.out.println("[!] Deseja registrar outra variável conhecida? [S/N]");
            option = utils.read.nextLine();
        }
    }
    */

    public void defineGoal(){
        String name;
        System.out.println("[+] Digite o nome da variável objetivo:");
        name = utils.read.nextLine();

        goalVariable = new Variable(name,"nãopreenchido",true);
        //establishFact(goalVariable);
    }

    

    //NÃO FINALIZADO
    public void convertToRules(){
      boolean bAux;
      String sConclusionAux;
      String[] splitConclusion;
      String line = null;
      String [] splitLine;
      Rule newRule = null;
      ArrayList<Variable> allPremises = new ArrayList<Variable>();
      Variable newVariable = null;
      
      int ruleNumber = 1;

      while((line = readFromFile()) != null){
        splitLine = line.split("\\s");
        
        allPremises = splitVariable(splitLine);

        sConclusionAux = splitLine[splitLine.length - 1];
        splitConclusion = sConclusionAux.split("=");

        if(splitConclusion[0].equals(goalVariable))
        {
            bAux = true;
        }
        else{
            bAux = false;
        }
        newVariable = new Variable(splitConclusion[0],splitConclusion[1],bAux);
        
       

        newRule = new Rule(allPremises, newVariable,ruleNumber);

        rules.add(newRule);
        
        ruleNumber++;
      }
    }
    
    
    //PRECISA ALTERAR
    public ArrayList<Variable> splitVariable(String[] splitLine){
      ArrayList<Variable> allPremises = new ArrayList<Variable>();
      String sVariableAux;
      String[] splitVariable;
      Variable newVariable = null;
      boolean bAux;
      int i=1;

      while(i<= splitLine.length - 2){
        sVariableAux = splitLine[i];
        splitVariable = sVariableAux.split("=");
        
        newVariable = new Variable(splitVariable[0],splitVariable[1],false);

        allPremises.add(newVariable);

        i++;
    
      }

      return allPremises;
    }


    public Variable findVariable(String name, ArrayList<Variable> variables){
        Variable st;
       for(int i = 0; variables.size()>i;i++){
           st = variables.get(i);
           if(st.getName().equals(name)){
               return st;
           }
       }
       return null;
    }

    public String readFromFile(){
      String line = null;

      try{
        line = readArch.readLine();
      }catch(IOException e){
        System.out.println("[!] Erro: Falha ao ler o arquivo!");
      }

      return line;
    }

    public void result(boolean res){
        System.out.println("[!] A resposta é: " + res);
    }
}
