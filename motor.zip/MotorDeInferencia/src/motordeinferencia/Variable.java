package motordeinferencia;

public class Variable {
    private String name;
    private String value;
    private boolean objetive;
    private float confidence;

    public Variable(String title, String value,float confidence){
        this.name = title;
        this.value = value;
        this.confidence = confidence;
    }

    public String getName() {
        return name;
    }

    public boolean isObjetive(){
        return objetive;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setObjetive(boolean objetive) {
        this.objetive = objetive;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public float getConfidence() {
        return confidence;
    }

    public void setConfidence(float confidence) {
        this.confidence = confidence;
    }
    

}
