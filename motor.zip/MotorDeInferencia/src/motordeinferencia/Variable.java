package motordeinferencia;

public class Variable {
    private String name;
    private String value;
    private boolean objetive;

    public Variable(String title, String value,boolean objetive){
        this.name = title;
        this.value = value;
        this.objetive = false;
    }

    public String getName() {
        return name;
    }

    public boolean isObjetive(){
        return objetive;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setObjetive(boolean objetive) {
        this.objetive = objetive;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
