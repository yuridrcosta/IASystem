package motordeinferencia;

public class MotorDeInferencia{

    static Utils utils;

    public static void main(String[] args) {
        utils.entry();
    }
}
