package motordeinferencia;

import java.util.ArrayList;

public class Rule{
  private ArrayList<Variable> premises = new ArrayList<Variable>();
  private Variable conclusion;
  private int ruleNumber;
  private boolean rejected = false;

  public Rule(ArrayList<Variable> premises, Variable conclusion, int ruleNumber){
    this.premises = premises;
    this.conclusion = conclusion;
    this.ruleNumber = ruleNumber;
  }

  public void setPremises(ArrayList<Variable> premises){
    this.premises = premises;
  }

  public ArrayList<Variable> getPremises(){
    return premises;
  }

  public Variable getConclusion(){
    return conclusion;
  }

  public void setConclusion(Variable conclusion){
    this.conclusion = conclusion;
  }

  public boolean isRejected() {
    return rejected;
  }

    public void setRejected(boolean rejected) {
        this.rejected = rejected;
    }
  
  
  

}