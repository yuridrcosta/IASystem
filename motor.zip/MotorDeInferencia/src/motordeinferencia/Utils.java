package motordeinferencia;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Utils{

    static Scanner read = new Scanner(System.in);
    static Engine engine = new Engine();

    public static void entry() {
        int option;
        String saux;
        boolean execute = false;
        while(!execute){
            System.out.println("[!] Menu de Opções:");
            System.out.println("    [1] Registrar base de regras");
            System.out.println("    [2] Definir variáveis-objetivo");
            System.out.println("    [3] Executar");
            option = read.nextInt();
            saux = read.nextLine();
        
            switch(option){
                case 1:
                    engine.askForRules();
                    engine.testRules();
                    break;
                //case 2:
                //    engine.defineVariables();
                //    break;
                case 2:
                    engine.defineGoal();
                    break;
                case 3:
                    execute = true;
                    engine.run();
                    break;
                case 5://TESTES
                    
                    
                    /* Teste da função match rules
                    Variable var1 = new Variable("A","present",false);
                    Variable var2 = new Variable("B","notpresent",false);
                    Variable var3 = new Variable("C","present",false);
                    Variable var4 = new Variable("B","present",false);
                    ArrayList<Variable> testPremises = new ArrayList<Variable>();
                    
                    testPremises.add(var1);
                    testPremises.add(var2);
                    Rule testRule = new Rule(testPremises,var3,1);
                    engine.known.add(var1);
                    engine.known.add(var4);
                    
                    
                    if(engine.matchRule(testRule)){
                        System.out.println("Deu match!!!!!");
                    }else{
                        System.out.println("It's not a match!!!");
                    }
                    */
                    
                    /*
                    Variable var1 = new Variable("A","present",false);
                    Variable var2 = new Variable("B","notpresent",false);
                    Variable var3 = new Variable("C","present",false);
                    Variable var4 = new Variable("B","present",false);
                    ArrayList<Variable> testPremises = new ArrayList<Variable>();
                    
                    testPremises.add(var1);
                    testPremises.add(var2);
                    Rule testRule = new Rule(testPremises,var3,1);
                    engine.known.add(var1);
                    engine.known.add(var4);
                    
                    
                    if(engine.matchRule(testRule)){
                        System.out.println("Deu match!!!!!");
                    }else{
                        System.out.println("It's not a match!!!");
                    }
                    break;
                    */
            }
        }
    }
    
    public int readInt(){
        int value = 10000000;
        value = read.nextInt();
       try{
            value = read.nextInt();
        }catch(InputMismatchException e){
            System.out.println("[!] ERRO: Você deve digitar um valor inteiro");
        }
        
        String saux = read.nextLine();
        return value;
    }
    public float readFloat(){
        float value = 10000000;
        
        try{
            value = read.nextFloat();
        }catch(InputMismatchException e){
            System.out.println("[!] ERRO: Você deve digitar um valor flutuante! Lembre-se: Usa-se virgula e não ponto");
        }
        
        String saux = read.nextLine();
        return value;
    }
}
