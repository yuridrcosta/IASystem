package motordeinferencia;

import java.util.Scanner;

public class Utils{

    static Scanner read = new Scanner(System.in);
    static Engine engine = new Engine();

    public static void entry() {
        int option;
        String saux;
        boolean execute = false;
        while(!execute){
            System.out.println("[!] Menu de Opções:");
            System.out.println("    [1] Registrar base de regras");
            System.out.println("    [2] Definir variáveis");
            System.out.println("    [3] Definir variáveis-objetivo");
            System.out.println("    [4] Executar");
            option = read.nextInt();
            saux = read.nextLine();
        
            switch(option){
                case 1:
                    engine.askForRules();
                    break;
                case 2:
                    engine.defineVariables();
                    break;
                case 3:
                    engine.defineGoal();
                    break;
                case 4:
                    execute = true;
                    engine.run();
                    break;
            }
        }
    }




}
